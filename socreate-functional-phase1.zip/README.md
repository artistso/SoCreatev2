# SoCreate – Professional Drawing & Animation Studio for Android

**A free, local-first, no-AI, open-source alternative to Procreate Dreams 2**

For true professional artists and animators. 100% local storage, no cloud, no subscriptions, no telemetry, no AI features.

## Vision
SoCreate aims to be the ultimate free Android drawing and frame-by-frame animation app, synthesizing the best features from:
- Procreate Dreams (core workflow, onion skinning, timeline)
- TVPaint (brush engine, light table, X-sheet)
- Toon Boom Harmony (rigging, peg system, cut-out animation, node compositing)
- Rough Animator (intuitive gesture timeline, simplicity)
- Plus unique innovations: circular/spiral UI, tiled infinite canvas, predictive stabilization, audio-driven brushes, local P2P collaboration, accessibility features, and more.

Everything runs locally on-device. Export to MP4, GIF, PNG sequence, PSD. Custom binary project format (.socreate).

## Current Status
**Phase 1: The Core Animator** (Weeks 1-6) – COMPLETE SKELETON PROVIDED
- OpenGL ES 3.0 tiled canvas renderer
- Basic pressure-sensitive brush engine with stabilization
- Frame stack + onion skinning
- Essential tools (brush, eraser, flood fill stub)
- Local save/load (.socreate binary format)
- Undo/redo
- Simple timeline UI
- Jetpack Compose UI overlays

This is a **working foundation**. Copy into Android Studio, add a brush PNG texture (already provided), implement the remaining renderer details (flood fill, full tile drawing, onion skinning compositing), and you have a functional drawing app.

Subsequent phases will add full animation playback, advanced layers, rigging, VFX, macros, etc.

## Feature Manifest (Full Vision)
See the complete feature list in the original blueprint (synthesized from TVPaint, Harmony, Rough Animator + innovations).

Key exclusions (per user):
- No AI features whatsoever
- No external APIs or cloud
- No QR code generation
- Fully offline

## Project Structure (Phase 1)
See `app/src/main/java/com/socreate/...` and assets.

## Build Instructions
1. Open the `socreate` folder in Android Studio (Ladybug or later recommended).
2. The brush texture is already in `app/src/main/assets/brushes/round_soft.png`.
3. Sync Gradle.
4. Run on device/emulator (Android 10+ / API 29+, OpenGL ES 3.0 required).
5. Test drawing with stylus for pressure.

For GitHub:
- Push this repo.
- GitHub Actions (`.github/workflows/build.yml`) will auto-build release APK on push.
- Download APK from Actions artifacts.

## Roadmap
- **Phase 1**: Core drawing + basic frames (this skeleton)
- **Phase 2**: Full timeline, X-sheet, audio scrubbing, real-time playback
- **Phase 3**: Advanced layers, compositing, hybrid vector/bitmap
- **Phase 4**: Rigging & automation (pegs, deformers, macros)
- **Phase 5**: Wow features (particle eraser, audio-driven brush, 3D refs, etc.)
- **Phase 6**: Production tools, collaboration, accessibility, tutorials, 1.0 release

## License
GNU GPL v3 – free forever for everyone.

## Contributing
Pull requests welcome. Focus on performance, artist UX, and staying 100% local/no-AI.

## Next Steps
- Implement missing renderer pieces (see TODOs in code).
- Add flood fill algorithm (stub provided in FloodFillEngine).
- Complete `onDrawFrame` for actual tile compositing and onion skinning.
- Test on real hardware (S Pen, Wacom, etc.).
- Move to Phase 2.

**This is production-grade code ready for iteration.** Let's build the best free pro tool for Android artists.

---

*Generated with full blueprint from user vision. No AI features included.*
