package com.socreate.engine

import android.view.MotionEvent
import com.socreate.model.Brush
import com.socreate.rendering.SoCreateRenderer
import kotlin.math.hypot

class BrushEngine(private val renderer: SoCreateRenderer) {
    private var lastX = 0f
    private var lastY = 0f
    private var lastPressure = 1f
    private val strokePoints = mutableListOf<PointWithPressure>()

    fun processTouchEvent(event: MotionEvent) {
        val x = event.x
        val y = event.y
        val pressure = event.getPressure(0)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                strokePoints.clear()
                addPoint(x, y, pressure)
                renderer.drawBrushStamp(x, y, pressure, renderer.currentBrush)
            }
            MotionEvent.ACTION_MOVE -> {
                addPoint(x, y, pressure)
                interpolateStroke()
            }
            MotionEvent.ACTION_UP -> {
                strokePoints.clear()
                // TODO: In full version, commit the stroke to the current frame's tiles
                // and push an UndoableAction to UndoManager
            }
        }
        lastX = x
        lastY = y
        lastPressure = pressure
    }

    private fun addPoint(x: Float, y: Float, pressure: Float) {
        strokePoints.add(PointWithPressure(x, y, pressure))
    }

    private fun interpolateStroke() {
        if (strokePoints.size < 2) return
        val brush = renderer.currentBrush
        val step = brush.size * brush.spacing
        val last = strokePoints[strokePoints.size - 2]
        val current = strokePoints.last()
        val distance = hypot((current.x - last.x).toDouble(), (current.y - last.y).toDouble())
        val steps = (distance / step).toInt().coerceAtLeast(1)
        for (i in 1..steps) {
            val t = i.toFloat() / steps
            val x = last.x + (current.x - last.x) * t
            val y = last.y + (current.y - last.y) * t
            val pressure = last.pressure + (current.pressure - last.pressure) * t
            renderer.drawBrushStamp(x, y, pressure, brush)
        }
    }

    private data class PointWithPressure(val x: Float, val y: Float, val pressure: Float)
}
