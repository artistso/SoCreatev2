package com.socreate.engine

import com.socreate.model.Frame
import java.util.*

interface UndoableAction {
    fun undo()
    fun redo()
}

class StrokeAction(
    private val frame: Frame,
    private val layerIndex: Int,
    private val beforeTile: Pair<Int, Int>?,
    private val afterTile: Pair<Int, Int>?,
    private val beforePixels: IntArray?,
    private val afterPixels: IntArray?
) : UndoableAction {
    override fun undo() {
        if (beforeTile != null && beforePixels != null) {
            frame.layers[layerIndex].setTile(beforeTile.first, beforeTile.second, beforePixels)
        }
    }

    override fun redo() {
        if (afterTile != null && afterPixels != null) {
            frame.layers[layerIndex].setTile(afterTile.first, afterTile.second, afterPixels)
        }
    }
}

class UndoManager {
    private val undoStack = Stack<UndoableAction>()
    private val redoStack = Stack<UndoableAction>()

    fun push(action: UndoableAction) {
        undoStack.push(action)
        redoStack.clear()
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            val action = undoStack.pop()
            action.undo()
            redoStack.push(action)
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val action = redoStack.pop()
            action.redo()
            undoStack.push(action)
        }
    }
}
