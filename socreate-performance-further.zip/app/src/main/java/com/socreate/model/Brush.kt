package com.socreate.model

data class Brush(
    val name: String = "Round Soft",
    val textureAsset: String = "brushes/round_soft.png",
    var size: Float = 20f,
    var opacity: Float = 1f,
    var spacing: Float = 0.15f, // relative to size
    var pressureSensitivity: Boolean = true,
    var color: Int = 0xFF000000.toInt()
) {
    companion object {
        fun default() = Brush()
    }
}
